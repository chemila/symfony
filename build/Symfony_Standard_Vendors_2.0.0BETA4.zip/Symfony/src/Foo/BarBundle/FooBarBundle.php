<?php

namespace Foo\BarBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FooBarBundle extends Bundle
{
}
